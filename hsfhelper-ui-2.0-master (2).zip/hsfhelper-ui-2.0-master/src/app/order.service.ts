import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  //private baseUrl = 'http://localhost:8080/api';
  private baseUrl ='https://hsfhelper-services.onrender.com/api';

  constructor(private http: HttpClient) { }

  // Fetch orders for a specific customer
  getOrdersByCustomerId(customerId: number): Observable<Map<string, any[]>> {
    return this.http.get<Map<string, any[]>>(this.baseUrl+`/orders/${customerId}`);
  }

  placeOrder(OrderDetails: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/placeOrder`, OrderDetails, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }
}

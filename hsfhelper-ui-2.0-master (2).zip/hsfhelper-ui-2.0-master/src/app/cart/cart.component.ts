import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  userDetails: any;

  constructor(private cartService: CartService,private router: Router,private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.userDetails$.subscribe((user) => {
      this.userDetails = user;
    });
    this.getCartItems();
  }

  // Fetch all cart items
  getCartItems(): void {
    this.cartService.getCartItems(this.userDetails.customerId).subscribe(
      (data) => {
        // Filter out cart items with quantity 0 (if not handled by backend)
        this.cartItems = data.filter((item: any) => item.quantity > 0);
      },
      (error) => {
        console.error('Error fetching cart items:', error);
      }
    );
  }

  // Add or update cart item
  addToCart(serviceId: number, quantity: number): void {
    const cartItem = {
      customerId: this.userDetails.customerId,
      serviceId: serviceId,
      quantity: quantity
    };

    this.cartService.addOrUpdateCartItem(cartItem).subscribe(
      (response) => {
        console.log('Cart item added/updated:', response);
        this.getCartItems(); // Refresh the cart items
      },
      (error) => {
        console.error('Error adding/updating cart item:', error);
      }
    );
  }

  // Remove item from cart
  removeFromCart(cartId: number): void {
    this.cartService.deleteCartItem(cartId).subscribe(
      (response) => {
        console.log('Cart item removed:', response);
        this.getCartItems(); // Refresh the cart items
      },
      (error) => {
        console.error('Error removing cart item:', error);
      }
    );
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddressService {
  //private baseUrl='http://localhost:8080/api/addresses'
  private baseUrl ='https://hsfhelper-services.onrender.com/api/addresses';
  private saveAddress = '/add'; // Spring Boot API endpoint

  constructor(private http: HttpClient) {}

  getAddress(customerId: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/${customerId}`);
  }
}


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {  LoginService } from '../login.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  fullName: string = '';
  mobileNumber: string = '';
  gmail: string = '';
  age: number = 0;
  password: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';

  constructor(private loginService: LoginService, private router: Router) {}

  ngOnInit(): void {}

  onRegister() {
    if (this.password !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match';
      return;
    }

    const registrationData = {
      name: this.fullName,
      mobileNumber: this.mobileNumber,
      gmail: this.gmail,
      age: this.age,
      password: this.password,
      createdDt: new Date().toISOString(),
      role: 'ROLE_USER'  // Or set this dynamically based on the use case
    };

    this.loginService.register(registrationData).subscribe(
      (response) => {
       // console.log("logavail "+response);
        if (response && response.status === '00') {
          this.router.navigate(['/signin']);
        } else {
          this.errorMessage = 'Registration failed. Please try again.';
        }
      },
      (error) => {
        console.log("errorr  " +error);
        this.errorMessage = 'An error occurred. Please try again.';
      }
    );
  }
}

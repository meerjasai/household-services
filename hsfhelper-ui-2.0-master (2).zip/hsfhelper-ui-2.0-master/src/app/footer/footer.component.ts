import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  isCartComponent = false;
  constructor(private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe(() => {
      this.isCartComponent = this.router.url.includes('cart');
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-info',
  templateUrl: './order-info.component.html',
  styleUrls: ['./order-info.component.css']
})
export class OrderInfoComponent implements OnInit {
  orderDetails: any[] = [];

  constructor(
    private router: Router
  ) {}

  ngOnInit(): void {
    // Retrieve the state passed via the router (using history.state)
    const navigationState = history.state;

    if (navigationState && navigationState.orderDetails) {
      this.orderDetails = navigationState.orderDetails;
    } else {
      console.error('No order details available in the navigation state');
    }
  }
}

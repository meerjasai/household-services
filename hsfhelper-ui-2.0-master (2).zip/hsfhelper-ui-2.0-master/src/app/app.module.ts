import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { JoinUsComponent } from './join-us/join-us.component';
import { RegistrationComponent } from './registration/registration.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ServiceListComponent } from './service-list/service-list.component';
import { CartComponent } from './cart/cart.component';
import { ProfileComponent } from './profile/profile.component';
import { OrderInfoComponent } from './order-info/order-info.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PopupComponent } from './popup/popup.component';
import { PersonalInformationComponent } from './personal-information/personal-information.component';
import { AddressBookComponent } from './address-book/address-book.component';
import { AddressComponent } from './address/address.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LandingPageComponent,
    JoinUsComponent,
    RegistrationComponent,
    SignInComponent,
    HomeComponent,
    ServiceListComponent,
    CartComponent,
    ProfileComponent,
    OrderInfoComponent,
    CheckoutComponent,
    PopupComponent,
    PersonalInformationComponent,
    AddressBookComponent,
    AddressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

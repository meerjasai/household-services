import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceListService } from '../service-list.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  specialOffers: any[] = [];

  constructor(private serviceListService: ServiceListService, private router: Router) { }

  ngOnInit(): void {
    this.fetchSpecialOffers();
  }


  fetchSpecialOffers() {
    this.serviceListService.getSpecialOfferServices().subscribe(
      (data) => {
        this.specialOffers = data;
      },
      (error) => {
        console.error('Error fetching special offers', error);
      }
    );
  }

  exploreService() {
    this.router.navigate(['/services']);
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceListService {

  //private  baseUrl ='Http://localhost:8080/api/auth';
  private baseUrl ='https://hsfhelper-services.onrender.com/api/auth';
  private serviceList=this.baseUrl+'/services';
  private servicelistoffers=this.baseUrl+'/services/offers';
  constructor(private http: HttpClient) { }
  getServices(): Observable<any[]> {
    return this.http.get<any[]>(this.serviceList);
  }
  getSpecialOfferServices(): Observable<any[]> {
    return this.http.get<any[]>(this.servicelistoffers);
  }
  
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent {
  email: string = '';  // Change variable to email
  password: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router,private loginService:LoginService) {}
  onLogin() {
    this.loginService.login(this.email, this.password).subscribe(
      (response) => {
        console.log("logedin...");
        console.log("response......"+response.data);
        // Assuming the response has a `token` field
        console.log(response);
        if (response && response.customerId!=null) {
          console.log("came inside");
          console.log(response);
          this.authService.setUserDetails(response);
          //localStorage.setItem('token', response.token); // Store JWT in localStorage
          this.router.navigate(['/home']); // Navigate to the home page
        } else {
          this.errorMessage = 'Invalid credentials'; // Show error if no token
        }

      },
      (error) => {
        this.errorMessage = 'Login failed. Please try again.'; // Show error on failure
      }
    );
  }

  onRegister(): void {
    this.router.navigate(['/register']);  // Navigate to the sign-up page
  }
}

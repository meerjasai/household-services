import { Component, OnInit } from '@angular/core';
import { AddressService } from '../address.service';


@Component({
  selector: 'app-address-book',
  templateUrl: './address-book.component.html'
})
export class AddressBookComponent implements OnInit {
  addressList = [];

  constructor(private addressService: AddressService) {}

  ngOnInit() {
    this.loadAddresses(1);
  }

  loadAddresses(customerId: any) {
    this.addressService.getAddress(customerId).subscribe((data) => {
      this.addressList = data;
    });
  }

  addNewAddress() {
    // Navigate to add new address component
  }

  editAddress(id: number) {
    // Logic to edit address
  }

  // deleteAddress(id: number) {
  //   this.addressService.deleteAddress(id).subscribe(() => {
  //     this.loadAddresses();
  //   });
  // }
}

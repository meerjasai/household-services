// auth.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root', // Makes the service available application-wide
})
export class AuthService {
  // BehaviorSubject to store user data and allow real-time updates
  private userDetailsSubject = new BehaviorSubject<any>(null);

  // Observable to allow components to subscribe to user data changes
  userDetails$ = this.userDetailsSubject.asObservable();

  constructor() {}

  // Method to set user details after login
  setUserDetails(user: any): void {
    this.userDetailsSubject.next(user);
    localStorage.setItem('userDetails', JSON.stringify(user)); // Optional: Persist data across reloads
  }

  // Method to get the current user details
  getUserDetails(): any {
    return this.userDetailsSubject.value || JSON.parse(localStorage.getItem('userDetails') || 'null');
  }

  // Method to clear user details (e.g., on logout)
  clearUserDetails(): void {
    this.userDetailsSubject.next(null);
    localStorage.removeItem('userDetails'); // Clear data from localStorage
  }
}

import { Component } from '@angular/core';
import { PersonalInfoService } from '../personal-info.service';

@Component({
  selector: 'app-personal-information',
  templateUrl: './personal-information.component.html',
  styleUrl: './personal-information.component.css'
})
export class PersonalInformationComponent {
  firstName: string='';
  lastName: string='';
  screenName: string='';
  email: string='';
  dob: string='';
  gender: string='';
  telephone: string='';

  constructor(private personalInfoService: PersonalInfoService) {}

  restore() {
    // Logic to restore original information
  }

  update() {
    const data = {
      firstName: this.firstName,
      lastName: this.lastName,
      screenName: this.screenName,
      email: this.email,
      dob: this.dob,
      gender: this.gender,
      telephone: this.telephone
    };
    this.personalInfoService.updatePersonalInfo(data).subscribe();
  }
}

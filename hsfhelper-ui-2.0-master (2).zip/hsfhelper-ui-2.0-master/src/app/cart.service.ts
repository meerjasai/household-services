import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  //private baseUrl = 'http://localhost:8080/api/cart';
  private baseUrl ='https://hsfhelper-services.onrender.com/api/cart';

  constructor(private http: HttpClient) {}

  // Fetch cart items for a specific customer
  getCartItems(customerId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${customerId}`);
  }

  // Add or update cart item
  addOrUpdateCartItem(cartItem: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/add`, cartItem, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  // Delete cart item
  deleteCartItem(cartId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${cartId}`);
  }
}

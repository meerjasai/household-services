import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../order.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  ordersMap: any = {}; // Store the map with order number as key and product list as value
  selectedOrderDetails: any[] = []; // Store selected order details for display
  selectedTab: string = 'orders';
Array: any;
userDetails: any;

  constructor(private orderService: OrderService, private router: Router,private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.userDetails$.subscribe((user) => {
      this.userDetails = user;
    });
    this.loadOrders();
  }

  loadOrders() {
    this.orderService.getOrdersByCustomerId(this.userDetails.customerId).subscribe((data: any) => {
      this.ordersMap = data;
    });
  }
  getOrderNumbers(): string[] {
    return Object.keys(this.ordersMap);
  }

  viewOrderDetails(orderNumber: string): void {
    const orderDetails = this.ordersMap[orderNumber]|| [];
    
    if (orderDetails) {
      // Navigate to the OrderInfoComponent and pass the order details via state
      this.router.navigate(['/order-info'], { state: { orderDetails:orderDetails } });
    } else {
      console.error('Order details not found for order number:', orderNumber);
    }
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
    //this.router.navigate([tab]);
  }
}

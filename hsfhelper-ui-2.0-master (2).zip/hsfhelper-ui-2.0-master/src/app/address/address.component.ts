import { Component } from '@angular/core';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html'
})
export class AddressComponent {
  name: string ='';
  // Add other fields like mobile, etc.

  constructor(private addressService: AddressService) {}

  save() {
    const addressData = {
      name: this.name,
      // Add other fields
    };
   // this.addressService.saveAddress(addressData).subscribe();
  }

  reset() {
    // Logic to reset form
  }
}

export interface Order {
  customerId: number;
  serviceId: number;
  quantity: number;
  orderAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  address: string;
  orderDeliveredDt: string;
}

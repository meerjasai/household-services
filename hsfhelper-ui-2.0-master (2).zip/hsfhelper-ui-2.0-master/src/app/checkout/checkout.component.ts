import { Component, OnInit } from '@angular/core';
import { AddressService } from '../address.service';
import { CartService } from '../cart.service';
import { OrderService } from '../order.service';
import { Order } from './Order';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  addressList : any[]=[];
  cartItems: any[] = [];
  orderDetails: Order[] = [];
  totalPrice = 0;
  defaultAddress :any;
  selectedPayment = 'COD';
  orderConfirmed = false;
  deliveryTime: any;
  deliveryDate: any;
  orderDeliveredDt: string = ''; // Holds the selected date
  showPopup = false;
  popupMessage = '';
  userDetails: any;
  userEmail='';
  constructor(
    private addressService: AddressService,
    private cartService: CartService,
    private orderService: OrderService,
    private router :Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.authService.userDetails$.subscribe((user) => {
      this.userDetails = user;
      this.userEmail=this.userDetails.gmail;
    });
    this.loadAddressList();
    this.getCartItems();
  }

  loadAddressList() {
    this.addressService.getAddress(this.userDetails.customerId).subscribe((data) => {
      this.addressList = data;
      this.defaultAddress=this.addressList.find((address)=>address.defaultStatus ==='Y');
    });
  }
  getCartItems(): void {
    this.cartService.getCartItems(this.userDetails.customerId).subscribe(
      (data) => {
        // Filter out cart items with quantity 0 (if not handled by backend)
        this.cartItems = data.filter((item: any) => item.quantity > 0);
        this.totalPrice=this.calculateTotal();
      },
      (error) => {
        console.error('Error fetching cart items:', error);
      }
    );
  }

  calculateTotal() {
    return  this.cartItems.reduce((acc, item) => acc + (item.service.serviceCost * item.quantity), 0);
  }
   // Map cart items to order details
   populateOrderDetails() {
    this.orderDetails = this.cartItems.map((item) => {
      return {
        customerId: this.userDetails.customerId,
        serviceId: item.service.serviceId,
        quantity: item.quantity,
        orderAmount: this.totalPrice, // Calculate total cost
        paymentMethod: this.selectedPayment,
        paymentStatus: 'Done', // Default payment status
        address: this.defaultAddress.houseNum ||','||this.defaultAddress.area ||','||this.defaultAddress.landmark ||','|| this.defaultAddress.city ||','||this.defaultAddress.state ||','||this.defaultAddress.pincode ||','|| this.defaultAddress.phoneNumber,
        orderDeliveredDt:`${this.deliveryDate}T${this.deliveryTime}:00`
      };
    });
  }

  placeOrder() {
    // Ensure the user has selected a date
    if (!this.deliveryDate) {
      alert('Please select a delivery date.');
      return;
    }

    this.populateOrderDetails(); // Populate order details
    this.orderService.placeOrder(this.orderDetails).subscribe(
      (response) => {
        this.popupMessage = 'Order confirmed!';
        this.showPopup = true; 
       // Close popup after 3 seconds
      },
      (error) => {
        console.error('Order failed', error);
      }
    );
  }
  onPopupClose() {
    this.showPopup = false; // Hide the popup
    this.router.navigate(['/services']); // Navigate to services page
  }

  increaseQuantity(item: any) {
    item.quantity++;
    this.totalPrice=this.calculateTotal();
  }

  decreaseQuantity(item: any) {
    if (item.quantity > 1) {
      item.quantity--;
      this.totalPrice=this.calculateTotal();
    }
  }

  removeItem(item: any) {
    this.cartItems = this.cartItems.filter((cartItem) => cartItem !== item);
    this.totalPrice=this.calculateTotal();
  }
}

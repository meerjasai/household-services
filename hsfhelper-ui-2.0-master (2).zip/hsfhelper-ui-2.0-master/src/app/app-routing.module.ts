import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { RegistrationComponent } from './registration/registration.component';
import { SignInComponent } from './sign-in/sign-in.component'; // Import SignInComponent
import { HomeComponent } from './home/home.component';
import { ServiceListComponent } from './service-list/service-list.component';
import { CartComponent } from './cart/cart.component';
import { ProfileComponent } from './profile/profile.component';
import { OrderInfoComponent } from './order-info/order-info.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PersonalInformationComponent } from './personal-information/personal-information.component';
import { AddressBookComponent } from './address-book/address-book.component';
import { AddressComponent } from './address/address.component';

const routes: Routes = [
  { path: '', component: LandingPageComponent }, // Default route to the landing page
  { path: 'register', component: RegistrationComponent }, // Route for registration page
  { path: 'signin', component: SignInComponent }, // Route for sign-in page
  { path: 'home', component: HomeComponent }, // Route for home page
  { path: 'services', component: ServiceListComponent }, // Route for services page
  { path: 'cart', component: CartComponent }, // Route for cart page
  { path: 'profile', component: ProfileComponent },
  { path: 'order-info', component: OrderInfoComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'personal-information', component: PersonalInformationComponent },
  { path: 'addressBook', component: AddressBookComponent },
  { path: 'address', component: AddressComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

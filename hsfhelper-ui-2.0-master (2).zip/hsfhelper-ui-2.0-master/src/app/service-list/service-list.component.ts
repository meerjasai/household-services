import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
import { ServiceListService } from '../service-list.service';

@Component({
  selector: 'app-service-list',
  templateUrl: './service-list.component.html',
  styleUrls: ['./service-list.component.css']
})
export class ServiceListComponent implements OnInit {

  services: any[] = []; // Store fetched services here
  categories: string[] = ['All', 'Cleaning', 'Organizing', 'Carpet Cleaning']; // Example categories
  selectedCategory: string = 'All';
  customerId: number = 1;

  constructor(private http: HttpClient,private cartService: CartService,private serviceListService :ServiceListService, private router: Router) { }

  ngOnInit(): void {
    this.fetchServices();  // Fetch services when the component loads
  }

  fetchServices(): void {
      this.serviceListService.getServices().subscribe(
        (data) => {
          this.services = data;
        },
        (error) => {
          console.error('Error fetching special offers', error);
        }
      );
    
  }

  // Filter services by selected category (optional based on user interaction)
  filterServices(): void {
    if (this.selectedCategory === 'All') {
      this.fetchServices(); // Re-fetch all services if 'All' is selected
    } else {
      this.services = this.services.filter(service => service.serviceType === this.selectedCategory);
    }
  }
  addToCart(serviceId:any) {
    const cartItem = {
      customerId: this.customerId,
      serviceId: serviceId,
      quantity: 1
    };
    this.cartService.addOrUpdateCartItem(cartItem).subscribe(
      (response) => {
        console.log('Cart item added/updated:', response);
         // Refresh the cart items
         this.router.navigate(['/cart']);
      },
      (error) => {
        console.error('Error adding/updating cart item:', error);
      }
    );
  }
  }


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  //private baseUrl ='http://localhost:8080';
  private baseUrl ='https://hsfhelper-services.onrender.com';

  private loginUrl = this.baseUrl+'/api/auth/login'; // Update with your actual backend URL
  private registerUrl=this.baseUrl+'/api/auth/register';

  constructor(private http: HttpClient) { }

  login(gmail: string, password: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
     const body = JSON.stringify({ gmail, password });
    
    return this.http.post<any>(this.loginUrl, body, { headers }).pipe(
      catchError(this.handleError)
    );
  }
  register(data: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.registerUrl, data, { headers }).pipe(
      catchError(this.handleError)
    );
  }
  private handleError(error: any) {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}

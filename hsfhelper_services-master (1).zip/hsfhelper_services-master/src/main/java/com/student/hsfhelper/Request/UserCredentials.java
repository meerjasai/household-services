package com.student.hsfhelper.Request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// UserCredentials.java
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class UserCredentials {
    private String username;
    private String password;

    // Getters and Setters
}


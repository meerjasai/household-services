package com.student.hsfhelper.Controller;

import com.student.hsfhelper.Entity.Address;
import com.student.hsfhelper.Request.AddressRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.student.hsfhelper.Service.AddressService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressService addressService;

    // 1. Insert a new address
    @PostMapping("/add")
    public ResponseEntity<Address> addAddress(@RequestBody AddressRequest address) {
        Address createdAddress = addressService.addAddress(address);
        return ResponseEntity.ok(createdAddress);
    }

    // 2. Get all addresses for a customer
    @GetMapping("/{customerId}")
    public ResponseEntity<List<Address>> getAllAddresses(@PathVariable int customerId) {
        List<Address> addresses = addressService.getAllAddressesForCustomer(customerId);
        return ResponseEntity.ok(addresses);
    }

    // 3. Update an address
    @PutMapping("/update")
    public ResponseEntity<Address> updateAddress(@RequestBody Address address) {
        Optional<Address> updatedAddress = addressService.updateAddress(address);
        return updatedAddress.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}

package com.student.hsfhelper.Request;

// CustomUserDetails.java
import com.student.hsfhelper.Entity.CustomerDetails;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;

public class CustomUserDetails implements UserDetails {
    private final CustomerDetails customer;

    public CustomUserDetails(CustomerDetails customer) {
        this.customer = customer;
    }
    public CustomerDetails getCustomerDetails() {
        CustomerDetails details = new CustomerDetails();
        details.setCustomerId(customer.getCustomerId());
        details.setName(customer.getName());
        details.setAge(customer.getAge());
        details.setGmail(customer.getGmail());
        details.setMobileNumber(customer.getMobileNumber());
        return details;
    }
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null; // Implement roles if needed
    }

    @Override
    public String getPassword() {
        return customer.getPassword();
    }

    @Override
    public String getUsername() {
        return customer.getName();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}


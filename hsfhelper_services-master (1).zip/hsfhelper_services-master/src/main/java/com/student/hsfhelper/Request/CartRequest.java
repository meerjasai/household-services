package com.student.hsfhelper.Request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor @Setter @Getter @NoArgsConstructor
public class CartRequest {
    private Integer customerId;
    private Long serviceId;
    private int quantity;

    // Getters and Setters
}


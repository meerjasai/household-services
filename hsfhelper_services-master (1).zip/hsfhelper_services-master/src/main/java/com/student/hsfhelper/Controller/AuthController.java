package com.student.hsfhelper.Controller;

import com.student.hsfhelper.Entity.CustomerDetails;
import com.student.hsfhelper.Entity.ServiceEntity;
import com.student.hsfhelper.Repository.CustomerDetailsRepository;
import com.student.hsfhelper.Repository.ServiceRepository;
import com.student.hsfhelper.Request.LoginRequest;
import com.student.hsfhelper.Response.ApiResponse;
import com.student.hsfhelper.Response.JwtResponse;
import com.student.hsfhelper.filter.JwtTokenProvider;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
@AllArgsConstructor
public class AuthController {

    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;
    private final CustomerDetailsRepository customerDetailsRepository;
    private final PasswordEncoder passwordEncoder;
    private final ServiceRepository serviceRepository;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getGmail(), loginRequest.getPassword())
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = jwtTokenProvider.generateToken(authentication);

            // Return the JWT token in the response
            System.out.println(authentication.getPrincipal().toString());
            User usercred = (User) authentication.getPrincipal();
            CustomerDetails userDetails = customerDetailsRepository.findByGmail(usercred.getUsername());
            return ResponseEntity.ok(userDetails);

        } catch (Exception e) {
           e.printStackTrace();
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody CustomerDetails user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        customerDetailsRepository.save(user);
       return ResponseEntity.status(HttpStatus.OK).body(new ApiResponse("00","SUCCESS"));
    }
    @GetMapping("/services")
    public ResponseEntity<List<ServiceEntity>> getAllServices() {
        List<ServiceEntity> services = serviceRepository.findAll();
        return ResponseEntity.ok(services);
    }
    @GetMapping("/services/offers")
    public ResponseEntity<List<ServiceEntity>> getAllServicesOffers() {
        List<ServiceEntity> services = serviceRepository.findAll();
        services=services.stream().sorted(Comparator.comparingInt(ServiceEntity::getDiscount).reversed()).limit(3).collect(Collectors.toList());
        return ResponseEntity.ok(services);
    }
    @PostMapping("/create/service")
    public ResponseEntity<ServiceEntity> createService(@RequestBody ServiceEntity service) {
        ServiceEntity serviceSaved=serviceRepository.save(service);
        return ResponseEntity.ok(serviceSaved);
    }
}

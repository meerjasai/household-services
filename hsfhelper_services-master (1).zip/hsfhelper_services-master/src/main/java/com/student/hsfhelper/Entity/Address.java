package com.student.hsfhelper.Entity;

import com.student.hsfhelper.Request.AddressRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "addresses")
@Setter @Getter @NoArgsConstructor @AllArgsConstructor
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long addressId;

    private int customerId;

    private String houseNum;
    private String area;
    private String landmark;
    private String city;
    private String state;
    private String pincode;
    private String phoneNumber;

    @Column(length = 1)
    private String defaultStatus; // 'Y' or 'N'
    private LocalDateTime createdAt;
    private LocalDateTime updatedDt;

    public Address(AddressRequest address){
        this.customerId=address.getCustomerId();
        this.houseNum=address.getHouseNum();
        this.area=address.getArea();
        this.landmark=address.getLandmark();
        this.city=address.getCity();
        this.state=address.getCity();
        this.pincode=address.getPincode();
        this.phoneNumber=address.getPhoneNumber();
        this.defaultStatus=address.getDefaultStatus();
        this.createdAt=LocalDateTime.now();
        this.updatedDt=LocalDateTime.now();
    }
}

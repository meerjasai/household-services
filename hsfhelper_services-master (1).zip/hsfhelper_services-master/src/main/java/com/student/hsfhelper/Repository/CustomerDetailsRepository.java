package com.student.hsfhelper.Repository;

import com.student.hsfhelper.Entity.CustomerDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerDetailsRepository extends JpaRepository<CustomerDetails,Integer> {
    CustomerDetails findByGmail(String gmail);
}

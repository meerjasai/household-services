package com.student.hsfhelper.Service;

import com.student.hsfhelper.Entity.Address;
import com.student.hsfhelper.Request.AddressRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.student.hsfhelper.Repository.AddressRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    public Address addAddress(AddressRequest address) {
        // Ensure only one address is set as default
        if ("Y".equalsIgnoreCase(address.getDefaultStatus())) {
            setDefaultAddressToNo(address.getCustomerId());
        }
        Address addressNew=new Address(address);
        return addressRepository.save(addressNew);
    }

    public List<Address> getAllAddressesForCustomer(int customerId) {
        return addressRepository.findByCustomerId(customerId);
    }

    public Optional<Address> updateAddress(Address updatedAddress) {
        Optional<Address> existingAddressOpt = addressRepository.findById(updatedAddress.getAddressId());

        if (existingAddressOpt.isPresent()) {
            Address existingAddress = existingAddressOpt.get();

            // Update the existing address
            existingAddress.setHouseNum(updatedAddress.getHouseNum());
            existingAddress.setArea(updatedAddress.getArea());
            existingAddress.setLandmark(updatedAddress.getLandmark());
            existingAddress.setCity(updatedAddress.getCity());
            existingAddress.setState(updatedAddress.getState());
            existingAddress.setPincode(updatedAddress.getPincode());
            existingAddress.setPhoneNumber(updatedAddress.getPhoneNumber());

            // Handle default status
            if ("Y".equalsIgnoreCase(updatedAddress.getDefaultStatus())) {
                setDefaultAddressToNo(existingAddress.getCustomerId());
                existingAddress.setDefaultStatus("Y");
            } else {
                existingAddress.setDefaultStatus("N");
            }

            return Optional.of(addressRepository.save(existingAddress));
        }

        return Optional.empty();
    }

    private void setDefaultAddressToNo(int customerId) {
        List<Address> customerAddresses = addressRepository.findByCustomerId(customerId);
        for (Address address : customerAddresses) {
            if ("Y".equalsIgnoreCase(address.getDefaultStatus())) {
                address.setDefaultStatus("N");
                addressRepository.save(address);
            }
        }
    }
}


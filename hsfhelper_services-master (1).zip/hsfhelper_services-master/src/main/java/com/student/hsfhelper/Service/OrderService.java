package com.student.hsfhelper.Service;

import com.student.hsfhelper.Entity.CustomerOrder;
import com.student.hsfhelper.Entity.Order;
import com.student.hsfhelper.Entity.ServiceEntity;
import com.student.hsfhelper.Repository.CustomerOrderRepository;
import com.student.hsfhelper.Repository.OrderRepository;
import com.student.hsfhelper.Repository.ServiceRepository;
import com.student.hsfhelper.Request.OrderDetails;
import com.student.hsfhelper.Response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

@Service
public class OrderService {

    @Autowired
    private CustomerOrderRepository customerOrderRepo;

    @Autowired
    private OrderRepository orderRepo;
    @Autowired
    private ServiceRepository serviceRepository;

    public Map<Integer, List<Order>> getAllOrdersForCustomer(int customerId) {
        // Fetch orders for a customer, assuming customer ID is known (for demo, hardcoded)
        List<Order> customerOrders = customerOrderRepo.findByCustomerId(customerId).stream().map(i->i.getOrders()).collect(Collectors.toList());
        Map<Integer, List<Order>> ordersMap = customerOrders.stream().collect(groupingBy(Order::getOrderNumber));
        return ordersMap;
    }

    public ApiResponse orderService(List<OrderDetails> orderDetails){
      ApiResponse response =new ApiResponse();
        int orderNumber = orderRepo.findMaxOrderNumber() + 1;
        List<Order>orderList=new ArrayList<>();
        orderDetails.forEach(i->{
            ServiceEntity service=serviceRepository.findById(i.getServiceId()).orElse(new ServiceEntity());
            Order order=new Order(i,orderNumber,service);
            orderList.add(order);
        });
        orderRepo.saveAll(orderList);
        response.setMessage("Order Conformed");
        response.setStatus("00");
      return response;
    }
}


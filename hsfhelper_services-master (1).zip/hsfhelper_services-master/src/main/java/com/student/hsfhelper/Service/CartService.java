package com.student.hsfhelper.Service;

import com.student.hsfhelper.Entity.Cart;
import com.student.hsfhelper.Entity.CustomerDetails;
import com.student.hsfhelper.Entity.ServiceEntity;
import com.student.hsfhelper.Repository.CartRepository;
import com.student.hsfhelper.Repository.CustomerDetailsRepository;
import com.student.hsfhelper.Repository.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CustomerDetailsRepository customerRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    public Cart addToCart(Integer customerId, Long serviceId, int quantity) {
        // Fetch customer and service objects
        CustomerDetails customer = customerRepository.findById(customerId).orElseThrow(() -> new RuntimeException("Customer not found"));
        ServiceEntity service = serviceRepository.findById(serviceId).orElseThrow(() -> new RuntimeException("Service not found"));

        // Check if the service is already in the cart
        Optional<Cart> existingCart = cartRepository.findByCustomerCustomerIdAndServiceServiceId(customerId, serviceId);
        Cart cart;

        if (existingCart.isPresent()) {
            // Update the quantity if the service is already in the cart
            cart = existingCart.get();
            cart.setQuantity(quantity);
            cart.setModifiedDt(LocalDateTime.now());
        } else {
            // Otherwise, create a new cart entry
            cart = new Cart();
            cart.setCustomer(customer);
            cart.setService(service);
            cart.setQuantity(quantity);
            cart.setModifiedDt(LocalDateTime.now());
        }

        return cartRepository.save(cart);
    }

    public void removeFromCart(Integer customerId, Long serviceId) {
        Optional<Cart> cart = cartRepository.findByCustomerCustomerIdAndServiceServiceId(customerId, serviceId);
        cart.ifPresent(cartRepository::delete);
    }

    public List<Cart> getCustomerCart(Integer customerId) {
        return cartRepository.findByCustomerCustomerId(customerId);
    }
}


package com.student.hsfhelper.Request;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AddressRequest {
    private int customerId;

    private String houseNum;
    private String area;
    private String landmark;
    private String city;
    private String state;
    private String pincode;
    private String phoneNumber;

    @Column(length = 1)
    private String defaultStatus;


}

package com.student.hsfhelper.Controller;

import com.student.hsfhelper.Entity.CustomerOrder;
import com.student.hsfhelper.Entity.Order;
import com.student.hsfhelper.Request.OrderDetails;
import com.student.hsfhelper.Response.ApiResponse;
import com.student.hsfhelper.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Get all orders for a customer
    @GetMapping("/orders/{customerId}")
    public Map<Integer, List<Order>> getAllOrders(@PathVariable("customerId") int customerId) {
        return orderService.getAllOrdersForCustomer(customerId);
    }
    @PostMapping("/placeOrder")
    public ApiResponse orderService(@RequestBody List<OrderDetails> orderDetails){
        return orderService.orderService(orderDetails);
    }
}

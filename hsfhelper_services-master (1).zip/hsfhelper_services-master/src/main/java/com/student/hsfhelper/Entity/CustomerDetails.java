package com.student.hsfhelper.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "customer_details")
@Getter @Setter
public class CustomerDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //@JsonIgnore
    private Integer customerId;
    private String name;
    private Integer age;
    private String gmail;
    private String mobileNumber;
    private String password;
    private String role;
    private LocalDateTime createdDt;


}

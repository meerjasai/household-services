package com.student.hsfhelper.Controller;

import com.student.hsfhelper.Entity.Cart;
import com.student.hsfhelper.Request.CartRequest;
import com.student.hsfhelper.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // Add service to cart
    @PostMapping("/add")
    public ResponseEntity<Cart> addToCart(@RequestBody CartRequest cartRequest) {
        Cart cart = cartService.addToCart(cartRequest.getCustomerId(), cartRequest.getServiceId(), cartRequest.getQuantity());
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }

    // Remove service from cart
    @DeleteMapping("/remove")
    public ResponseEntity<String> removeFromCart(@RequestParam Integer customerId, @RequestParam Long serviceId) {
        cartService.removeFromCart(customerId, serviceId);
        return new ResponseEntity<>("Service removed from cart", HttpStatus.OK);
    }

    // Get cart for a customer
    @GetMapping("/{customerId}")
    public ResponseEntity<List<Cart>> getCustomerCart(@PathVariable Integer customerId) {
        List<Cart> cart = cartService.getCustomerCart(customerId);
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }
}


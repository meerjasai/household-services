package com.student.hsfhelper.Request;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LoginRequest {
    private String gmail;
    private String password;

    // Getters and Setters
}


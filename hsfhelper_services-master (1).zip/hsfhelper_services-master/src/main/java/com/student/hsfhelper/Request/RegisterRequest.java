package com.student.hsfhelper.Request;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegisterRequest {
    private String name;
    private Integer age;
    private String gmail;
    private String mobileNumber;
    private String password;


}

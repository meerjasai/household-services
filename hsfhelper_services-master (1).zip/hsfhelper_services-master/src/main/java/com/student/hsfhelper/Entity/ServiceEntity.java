package com.student.hsfhelper.Entity;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Services")
@Setter @Getter @AllArgsConstructor @NoArgsConstructor
public class ServiceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   // @JsonIgnore
    private Long serviceId;

    @Column(name = "service_name", nullable = false)
    private String serviceName;

    @Column(name = "service_image_url")
    private String serviceImageUrl;

    @Column(name = "service_type")
    private String serviceType;

    @Column(name = "service_cost")
    private BigDecimal serviceCost;

    @Column(name = "created_dt")
    private LocalDateTime createdDt;

    private int discount;

    // Getters and setters

}


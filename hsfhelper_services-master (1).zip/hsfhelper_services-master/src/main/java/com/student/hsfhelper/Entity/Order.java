package com.student.hsfhelper.Entity;

import com.student.hsfhelper.Request.OrderDetails;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Order {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;
    private int orderNumber;
    @ManyToOne
    @JoinColumn(name = "service_id", nullable = false)
    private ServiceEntity service;
    private int quantity;
    private String address;
    private BigDecimal orderAmount;
    private String paymentMethod;
    private String paymentStatus;
    private String orderStatus;
    private LocalDateTime createdDt;
    private LocalDateTime updatedDt;
    private String orderAcceptedBy;
    private LocalDateTime OrderDeliveredDt;

    public Order(OrderDetails order , int orderNumber,ServiceEntity service){
      this.orderNumber=orderNumber;
      this.service=service;
      this.quantity=order.getQuantity();
      this.address=order.getAddress();
      this.orderAmount=order.getOrderAmount();
      this.paymentMethod=order.getPaymentMethod();
      this.orderStatus=order.getPaymentStatus();
      this.orderStatus="Conformed";
      this.createdDt=LocalDateTime.now();
      this.updatedDt=LocalDateTime.now();
      this.orderAcceptedBy="Kishore";
      this.OrderDeliveredDt=order.getOrderDeliveredDt();
    }

    // Getters, Setters
}


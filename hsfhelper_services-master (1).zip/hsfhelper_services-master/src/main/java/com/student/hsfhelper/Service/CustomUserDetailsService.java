package com.student.hsfhelper.Service;

import com.student.hsfhelper.Entity.CustomerDetails;
import com.student.hsfhelper.Repository.CustomerDetailsRepository;
import com.student.hsfhelper.Request.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final CustomerDetailsRepository customerDetailsRepository;

    public CustomUserDetailsService(CustomerDetailsRepository customerDetailsRepository) {
        this.customerDetailsRepository = customerDetailsRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String gmail) throws UsernameNotFoundException {
        CustomerDetails customer = customerDetailsRepository.findByGmail(gmail);
        if (customer == null) {
            throw new UsernameNotFoundException("User not found with email: " + gmail);
        }
        return new org.springframework.security.core.userdetails.User(customer.getGmail(), customer.getPassword(), List.of(new SimpleGrantedAuthority(customer.getRole())));
     //   return new CustomUserDetails(customer);

    }

}

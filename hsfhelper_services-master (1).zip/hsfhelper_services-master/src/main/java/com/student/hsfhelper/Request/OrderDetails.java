package com.student.hsfhelper.Request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@AllArgsConstructor @Getter @Setter @NoArgsConstructor
public class OrderDetails {
    private int customerId;
    private long serviceId;
    private int quantity ;
    private BigDecimal orderAmount;
    private String Address;
    private String paymentMethod;
    private String paymentStatus;
    private LocalDateTime OrderDeliveredDt;
}

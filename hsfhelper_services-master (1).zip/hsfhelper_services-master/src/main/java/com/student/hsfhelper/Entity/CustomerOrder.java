package com.student.hsfhelper.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "customer_order")
@AllArgsConstructor @NoArgsConstructor @Setter @Getter
public class CustomerOrder {
    @Id
    private int customerOrderId;
    private int customerId;
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order orders;

}


create database hsf_helper;
CREATE TABLE hsf_helper.customer_details (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    gmail VARCHAR(255) UNIQUE NOT NULL,
    mobile_number VARCHAR(15) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    created_dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hsf_helper.Services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(255) NOT NULL,
    service_image_url VARCHAR(255),
    service_type VARCHAR(100),
    service_cost DECIMAL(10, 2),
    created_dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hsf_helper.cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for the cart
    customer_id INT NOT NULL,                -- Foreign key for customer
    service_id BIGINT NOT NULL,                 -- Foreign key for the service
    quantity INT DEFAULT 1,                  -- Number of services in the cart (default 1)
    modified_dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Tracks last modification
    CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id),  -- Reference to customer table
    CONSTRAINT fk_service FOREIGN KEY (service_id) REFERENCES services(service_id)       -- Reference to service table
);

-- customer_order table
CREATE TABLE hsf_helper.customer_order (
    customer_id INT,
    order_id INT,
    service_id INT,
    order_status VARCHAR(20),
    service_image_url VARCHAR(255),
    created_dt TIMESTAMP,
    updated_dt TIMESTAMP,
    PRIMARY KEY (customer_id, order_id, service_id)
);

-- orders table
CREATE TABLE hsf_helper.orders (
    order_id INT AUTO_INCREMENT,
    service_id INT,
    quantity INT,
    address VARCHAR(255),
    order_amount DECIMAL(10, 2),
    payment_method VARCHAR(50),
    payment_status VARCHAR(50),
    order_status VARCHAR(50),
    created_dt TIMESTAMP,
    updated_dt TIMESTAMP,
    PRIMARY KEY (order_id, service_id)
);

CREATE TABLE hsf_helper.addresses (
    address_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id int NOT NULL,
    house_num VARCHAR(255),
    area VARCHAR(255),
    landmark VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    pincode VARCHAR(20),
    phone_number VARCHAR(20),
    default_status CHAR(1),
    created_dt TIMESTAMP,
    updated_dt TIMESTAMP,
    CONSTRAINT fk_address_customer FOREIGN KEY (customer_id) REFERENCES customer_details(customer_id)
);



